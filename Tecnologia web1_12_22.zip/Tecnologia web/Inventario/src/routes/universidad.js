const express = require("express");
const universidadSchema = require("../models/universidad_model");

const router = express.Router();
/*
C - Crear      | POST
R - Leer       | GET
U - Actualizar | PUT 
D - Eliminar   | DELETE 
*/

//Crear universidad
router.post('/crearUniversidad', (req, res) => {
  const universidad = universidadSchema(req.body);
  universidad
  .save()
  .then((data) => res.json(data))
  .catch((error) => res.json({message: error}));
});

// Listar universidad
router.get('/listarUniversidad', (req, res) => {
    universidadSchema
    .find()
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
});

//Listar universidad por id
router.get('/listarUniversidad/:id', (req, res) => {
    const { id } = req.params;
    universidadSchema
    .findById(id)
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
});


// Actulizaar universidad
router.put('/actualizarUniversidad/:id', (req, res) => {
   const { id } = req.params;
   const {nombre, direccion,telefono,fecha_creacion, fecha_edicion} = req.body;
   universidadSchema
    .updateOne({ _id: id}, {$set: {nombre, direccion,telefono,fecha_creacion, fecha_edicion} })
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
    res.send("Universidad actualizada")
});

// Eliminar universidad
router.delete('/eliminarUniversidad/:id', (req, res) => {
    const { id } = req.params;
    universidadSchema
    .remove({ _id: id})
    .then((data) => res.json(data))
    .catch((error) => res.json({message: error}));
    res.send("Universidad eliminada")
});


module.exports = router;